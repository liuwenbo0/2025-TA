#include"SqList.h"
void insert(SqList& list, int num){
    for(int i=0; i <list.size();++i){
        if(list[i]>=num){
            list.insert(list.begin()+i,num);
            return;
        }
    }
    list.push_back(num);
}