#include"SqList.hpp"

//将新增元素正确插入到线性表中，并不破坏其顺序性
//@param
//list:待处理线性表
//num：待插入元素
void insert(SqList& list, int num){
	//请在这里完成你的代码
}