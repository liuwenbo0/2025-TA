#pragma once
#include "MySort.hpp"

class InsertionSort: public MySort {
public:
  // 通过插入排序对int队列nums进行升序排序
  // @param
  // nums: 完整的待排序队列，最终排序的结果应存放在nums中
  void mysort(std::vector<int>& nums) {
    //请在这里完成你的代码
  }
private:
  int cnt;
};