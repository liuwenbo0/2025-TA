#include"Linklist.hpp"

//按要求修改双向循环链表的元素顺序
//@param
//list:待处理双向循环链表的head
void changeList(Linklist &list){
    //请在这里完成你的代码
}
