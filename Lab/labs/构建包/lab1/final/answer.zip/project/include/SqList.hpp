#pragma once
#include<iostream>
#include<vector>

typedef vector<int> SqList;

void insert(SqList& list, int num);